icfp-contest
============

To install dependencies:

```
sudo apt-get install ghc cabal-install
cabal update
cabal install HTTP http-conduit aeson mersenne-random-pure64 timers
```
